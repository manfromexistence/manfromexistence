import { Button } from "@/registry/default/ui/button"

export default function ButtonGhost() {
  return <Button variant="ghost">Ghost</Button>
}
