export default function TypographyLarge() {
  return <div className="text-lg font-semibold">Are you absolutely sure?</div>
}
