import { Badge } from "@/registry/default/ui/badge"

export default function BadgeSecondary() {
  return <Badge variant="secondary">Secondary</Badge>
}
