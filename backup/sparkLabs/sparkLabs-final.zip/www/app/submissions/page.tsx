"use client"

import { SiteFooter } from "@/components/site-footer";
import { SiteHeader } from "@/components/site-header";

const Submissions = () => {
    return (
        <>
            <SiteHeader />
            <div className="h-screen w-full flex-center">
            Submissions page is still on devlopment.
            </div>
            <SiteFooter />
        </>
    );
};
export default Submissions;