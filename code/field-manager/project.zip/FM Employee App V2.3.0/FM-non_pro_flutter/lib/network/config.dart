const baseURL = '';
const noInternetMsg = 'Oops No Internet';

const msg = 'message';
const status = 'status';
const int timeoutDuration = 30;
