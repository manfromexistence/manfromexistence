class MessageListModel {
  String? img;
  String? name;
  String? message;
  String? lastSeen;
  bool? isActive;

  MessageListModel(
      {this.img, this.name, this.message, this.lastSeen, this.isActive});
}
