package com.fieldmanager_hrms.flutter.fieldmanager_hrms_flutter

import io.flutter.embedding.android.FlutterFragmentActivity

class MainActivity: FlutterFragmentActivity()
